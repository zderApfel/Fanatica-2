<h1>Fanatica's Back, Baby!</h1>

<h2>Modpack Download: https://github.com/zderApfel/Fanatica-2/raw/master/Fanatica%202.zip</h2>
<h2>Discord link: https://discord.gg/9uf68Uvzvy</h2>

<p>Fanatica 2 is modpack the long-awaited sequel to a Minecraft Server beloved and cherished by a small but passionate group.</p>

<p>The server's modpack is designed to be a Vanilla+ pack that is both small enough to not stress out powerful computers, but with enough variability in the content to appease many different types of Minecraft players. This pack has:</p>

* **More Mobs!** - Thanks to mods like Alex's Mobs, Champions, Earth Mobs...
* **Technology!** - The Create mod and several expansions. We also have Immersive Aircraft!
* **Magic!** - Apotheosis makes enchanting more interesting while Botania adds plant magic
* **Places to see!** - Terralith adds countless new biomes all with the vanilla blockset, so your inventory isn't being clogged with random flowers like certain other mods. We also have countless new structures, dungeons, and villages to explore. The Nether and End got a fresh coat of paint as well
* Performance optimizations built in thanks to **Rubidium** (Forge version of Sodium)
* **So, much, more!**
